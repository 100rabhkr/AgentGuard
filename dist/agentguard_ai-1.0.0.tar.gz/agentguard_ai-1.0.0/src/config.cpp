#include "agentguard/config.hpp"

// Config is a plain struct with defaults. This file exists for
// future expansion (e.g., loading from file or environment variables).

namespace agentguard {
// Currently no implementation needed - all defaults are in the header.
} // namespace agentguard
